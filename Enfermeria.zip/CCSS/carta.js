const express = require("express");
const app = express();
const dotenv = require("dotenv");
dotenv.config();

// Conexión con la base de datos
const { connection } = require("../confbd.js");

// Obtener todos los datos personales
const getCSS = (request, response) => {
    connection.query("SELECT * FROM ccss", (error, results) => {
        if (error) throw error;
        response.status(200).json(results);
    });
};


const postCCSS = (request, response) => {
    const { Nombre, Apellido, Asegurado } = request.body;

    if (!Nombre || !Apellido || !Asegurado) {
        response.status(400).json({ error: 'Datos faltantes en la solicitud' });
        return;
    }

    connection.query(
        "INSERT INTO ccss (Nombre, Apellido, Asegurado) VALUES (?, ?, ?)",
        [Nombre, Apellido, Asegurado],
        (error, results) => {
            if (error) {
                console.error('Error en la consulta INSERT:', error);
                response.status(500).json({ error: 'Error en la consulta INSERT' });
                return;
            }
            response.status(201).json({ "Item añadido correctamente": results.affectedRows });
        }
    );
};

// Eliminar un registro en CCSS
const delCCSSS = (request, response) => {
    const { ID } = request.params;

    if (!ID) {
        response.status(400).json({ error: 'ID es requerido' });
        return;
    }

    connection.query(
        "DELETE FROM ccss WHERE ID = ?",
        [ID],
        (error, results) => {
            if (error) {
                console.error('Error en la consulta DELETE:', error);
                response.status(500).json({ error: 'Error en la consulta DELETE' });
                return;
            }
            response.status(200).json({ "Item eliminado": results.affectedRows });
        }
    );
};

// Actualizar un registro en CCSS (PUT)
const putCCSS = (request, response) => {
    const { ID } = request.params;
    const { Nombre, Apellido, Asegurado } = request.body;

    if (!ID || !Nombre || !Apellido || !Asegurado) {
        response.status(400).json({ error: 'Datos faltantes en la solicitud' });
        return;
    }

    connection.query(
        "UPDATE ccss SET Nombre = ?, Apellido = ?, Asegurado = ? WHERE ID = ?",
        [Nombre, Apellido, Asegurado, ID],
        (error, results) => {
            if (error) {
                console.error('Error en la consulta UPDATE:', error);
                response.status(500).json({ error: 'Error en la consulta UPDATE' });
                return;
            }
            response.status(200).json({ "Item actualizado correctamente": results.affectedRows });
        }
    );
};


app.route("/carta").get(getCSS);


app.route("/carta").post(postCCSS);


app.route("/carta/:ID").delete(delCCSSS);


app.route("/carta/:ID").put(putCCSS);

module.exports = app;

 