const express = require("express");
const app = express();
const dotenv = require("dotenv");
dotenv.config();

// Conexión con la base de datos
const { connection } = require("../confbd.js");

// Obtener todas las citas


const getCita = (request, response) => {
    connection.query("SELECT * FROM citas", (error, results) => {
        if (error) throw error;
        response.status(200).json(results);
    });
};

// Ruta para obtener datos personales
app.route("/carta").get(getCita);
module.exports = app;
