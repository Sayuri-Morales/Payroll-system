const express = require("express");
const app = express();
 
const dotenv = require("dotenv");
dotenv.config();
 
//conexión con la base de datos
const {connection} = require("../confbd.js");
 

// Obtener todos los datos personales
const getDatosPersonales = (request, response) => {
    connection.query("SELECT * FROM datospersonales", (error, results) => {
        if (error) throw error;
        response.status(200).json(results);
    });
};

// Ruta para obtener datos personales
app.route("/carta").get(getDatosPersonales);

// Agregar nuevos datos personales
const postDatosPersonales = (request, response) => {
    const { Nombre, Apellidos, Direccion } = request.body;

    if (!Nombre || !Apellidos || !Direccion) {
        response.status(400).json({ error: 'Datos faltantes en la solicitud' });
        return;
    }

    connection.query(
        "INSERT INTO datospersonales (Nombre, Apellidos, Direccion) VALUES (?, ?, ?)",
        [Nombre, Apellidos, Direccion],
        (error, results) => {
            if (error) {
                console.error('Error en la consulta INSERT:', error);
                response.status(500).json({ error: 'Error en la consulta INSERT' });
                return;
            }
            response.status(201).json({ "Item añadido correctamente": results.affectedRows });
        }
    );
};

// Ruta para POST
app.route("/carta").post(postDatosPersonales);

// Eliminar datos personales por IDPersona
const delDatosPersonales = (request, response) => {
    const IDPersona = request.params.IDPersona;

    connection.query(
        "DELETE FROM datospersonales WHERE IDPersona = ?",
        [IDPersona],
        (error, results) => {
            if (error) throw error;
            response.status(201).json({ "Item eliminado": results.affectedRows });
        }
    );
};

// Ruta para eliminar
app.route("/carta/:IDPersona").delete(delDatosPersonales);

// Verificar datos personales por IDPersona
const verificarDatosPersonales = (request, response) => {
    const { IDPersona } = request.params;

    connection.query(
        "SELECT Nombre, Apellidos, Direccion FROM datospersonales WHERE IDPersona = ?",
        [IDPersona],
        (error, results) => {
            if (error) throw error;

            if (results.length > 0) {
                response.status(200).json(results[0]);
            } else {
                response.status(404).json({ error: 'IDPersona no encontrado' });
            }
        }
    );
};

// Ruta para verificar datos personales
app.route("/carta/verificar/:IDPersona").get(verificarDatosPersonales);


module.exports = app;

 