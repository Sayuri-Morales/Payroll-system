const express = require("express");
const app = express();
 
const dotenv = require("dotenv");
dotenv.config();
 
//conexión con la base de datos
const {connection} = require("../confbd.js");
 

const getSinpe = (request, response) => {
    connection.query("SELECT * FROM sinpe",
    (error, results) => {
        if (error)
            throw error;
        response.status(200).json(results);
    });
};
//ruta
app.route("/carta")
.get(getSinpe);
 
 

const postSinpe = (request, response) => {
    const { Telefono, Persona, NumeroCuenta, Monto } = request.body;
    connection.query("INSERT INTO sinpe (Telefono, Persona, NumeroCuenta, Monto) VALUES (?,?,?,?) ",
    [Telefono, Persona, NumeroCuenta, Monto],
    (error, results) => {
        if (error)
            throw error;
        response.status(201).json({ "Item añadido correctamente": results.affectedRows });
    });
};
 
//ruta
app.route("/carta")
.post(postSinpe);
 
 

const delSinpe = (request, response) => {
    const Telefono = request.params.Telefono;
    connection.query("DELETE FROM sinpe WHERE Telefono = ?",
    [Telefono],
    (error, results) => {
        if (error)
            throw error;
        response.status(201).json({ "Item eliminado": results.affectedRows });
    });
};
//ruta
app.route("/carta/:Telefono")
.delete(delSinpe);
const putSinpe = (request, response) => {
    const Telefono = request.params.Telefono;
    const { Persona, NumeroCuenta, Monto } = request.body;
    connection.query("UPDATE sinpe SET Persona = ?, NumeroCuenta = ?, Monto = ? WHERE Telefono = ?",
    [Persona, NumeroCuenta, Monto, Telefono],
    (error, results) => {
        if (error)
            throw error;
        if (results.affectedRows === 0) {
            return response.status(404).json({ "Mensaje": "No se encontró el registro para actualizar" });
        }
        response.status(200).json({ "Item actualizado": results.affectedRows });
    });
};

// Ruta PUT
app.route("/carta/:Telefono")
.put(putSinpe);
 
module.exports = app;