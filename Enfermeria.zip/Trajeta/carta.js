const express = require("express");
const app = express();
 
const dotenv = require("dotenv");
dotenv.config();
 
//conexión con la base de datos
const {connection} = require("../confbd.js");
 
const getTarjeta = (request, response) => {
    connection.query("SELECT * FROM tarjeta",
    (error, results) => {
        if (error)
            throw error;
        response.status(200).json(results);
    });
};
 
//ruta
app.route("/carta")
.get(getTarjeta);
 
 
// Agregar una nueva tarjeta
const postTarjeta = (request, response) => {
    const { NumeroTarjeta, Monto, IDPersona } = request.body;

    if (!NumeroTarjeta || !Monto || !IDPersona) {
        response.status(400).json({ error: 'Datos faltantes en la solicitud' });
        return;
    }

    connection.query(
        "INSERT INTO tarjeta (NumeroTarjeta, Monto, IDPersona) VALUES (?, ?, ?)",
        [NumeroTarjeta, Monto, IDPersona],
        (error, results) => {
            if (error) {
                console.error('Error en la consulta INSERT:', error);
                response.status(500).json({ error: 'Error en la consulta INSERT' });
                return;
            }
            response.status(201).json({ "Item añadido correctamente": results.affectedRows });
        }
    );
};

// Ruta para POST
app.route("/carta").post(postTarjeta);
 
 
const delTarjeta = (request, response) => {
    const NumeroTarjeta = request.params.NumeroTarjeta;
    connection.query("DELETE FROM tarjeta WHERE NumeroTarjeta = ?",
    [NumeroTarjeta],
    (error, results) => {
        if (error)
            throw error;
        response.status(201).json({ "Item eliminado": results.affectedRows });
    });
};
 
//ruta
app.route("/carta/:NumeroTarjeta")
.delete(delTarjeta);
 
 
module.exports = app;