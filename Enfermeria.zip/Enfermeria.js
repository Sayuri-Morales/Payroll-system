const http = require('node:http');
const fs = require('node:fs');
const axios = require('axios');
const mysql = require('mysql2');
const qs = require('querystring');
const bodyParser = require('body-parser');

const conexion = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'root',
  database: 'webclinica'
});

conexion.connect(error => {
  if (error) {
    console.log('Problemas de conexion con mysql:', error);
  } else {console.log('Conectado a MySQL')}
});

const mime = {
  'html': 'text/html',
  'css': 'text/css',
  'png': 'image/png',
  'js': 'text/javascript',
};

const servidor = http.createServer((pedido, respuesta) => {
  const url = new URL('http://localhost:8888' + pedido.url);
  let camino = 'public' + url.pathname;
  if (camino === 'public/') camino = 'public/index.html';
  encaminar(pedido, respuesta, camino);
});

servidor.listen(8888)

function encaminar(pedido, respuesta, camino) {
  console.log(camino);
  switch (camino) {
    case 'public/registro_usuario': {
      registroU(pedido, respuesta);
      break;
    }
    case 'public/enviar_contacto': {
      enviarContacto(pedido, respuesta);
      break;
    }
    case 'public/agendar_cita': {
      agendarCita(pedido, respuesta);
      break;
    }
    case 'public/mostrar_citas': {
      obtenerCitas(respuesta);
      break;
    }
    case 'public/verContactos': {
      VerClientes(respuesta);
      break;
    }
    case 'public/verCitas': {
      verCitas(respuesta);
      break;
    }    
    case 'public/actualizar_usuario': {
      actualizarUsuario(pedido, respuesta);
      break;
    }
    case 'public/eliminar_usuario': {
      eliminarUsuario(pedido, respuesta);
      break;
    }
    case 'public/verContactos': {
      verContactos(respuesta);
      break;
    }
    case 'public/buscar_comentario': {
      buscarComentario(pedido, respuesta);
      break;
    }
    case 'public/cambiar_estado': {
      cambiarEstadoComentario(pedido, respuesta);
      break;
    }
    case 'public/verComentarios': {
      verComentarios(respuesta);
      break;
    }
    case 'public/consultar_comentarios': {
      consultarComentarios(pedido, respuesta);
      break;
    }
    case 'public/mostrar_comentarios': {
      mostrarComentarios(pedido, respuesta);
      break;
    }
    
    case 'public/eliminar_tarjeta': {
      if (pedido.method === 'POST') {
        procesarPost(pedido, respuesta, eliminarTarjeta);
      }
      break;
    }
    case 'public/ver_tarjetas': {
      if (pedido.method === 'GET') {
        obtenerTarjetas(respuesta);
      }
      break;
    }
    case 'public/anadir_tarjeta': {
      if (pedido.method === 'POST') {
        procesarPost(pedido, respuesta, agregarTarjeta);
      }
      break;
    }
    case 'public/verificar_datos_personales': {
      if (pedido.method === 'POST') {
        procesarPost(pedido, respuesta, verificarDatos);
      }
      break;
    }
    case 'public/ver_citas': {
      if (pedido.method === 'GET') {
        verCitas_Servicio(respuesta);
      }
      break;
    }
    case 'public/agregar_sinpe': {
      if (pedido.method === 'POST') {
          procesarPost(pedido, respuesta, agregarSinpe);
      }
      break;
  }
    case 'public/ccss':
      if (pedido.method === 'GET') {
        obtenerCCSS(respuesta);
      }
    break;
    case 'public/verificar_usuario': {
      if (pedido.method === 'POST') {
        procesarPost(pedido, respuesta, validarUsuario);
      }
      break;
    }
  
    

    


    default: {
      fs.stat(camino, error => {
        if (!error) {
          fs.readFile(camino, (error, contenido) => {
            if (error) {
              respuesta.writeHead(500, { 'Content-Type': 'text/plain' });
              respuesta.write('Error interno');
              respuesta.end();
            } else {
              const vec = camino.split('.');
              const extension = vec[vec.length - 1];
              const mimearchivo = mime[extension];
              respuesta.writeHead(200, { 'Content-Type': mimearchivo });
              respuesta.end(contenido);
            }
          });
        } else {
          respuesta.writeHead(404, { 'Content-Type': 'text/html' });
          respuesta.write('<!doctype html><html><head></head><body>Recurso inexistente</body></html>');
          respuesta.end();
        }
      });
    }
  }
}
function registroU(pedido, respuesta) {
  let info = '';
  pedido.on('data', datosparciales => {
    info += datosparciales;
  });
  pedido.on('end', () => {
    const formulario = new URLSearchParams(info);
    console.log(formulario);
    respuesta.writeHead(200, { 'Content-Type': 'text/html' });
    const pagina = `
      <!doctype html><html><head></head><body>
      ID: ${formulario.get('ID_Usuario')}<br>
      Nombre: ${formulario.get('Nombre_Usuario')}<br>
      Email: ${formulario.get('Email_Usuario')}<br>
      Telefono: ${formulario.get('Telefono_Usuario')}<br>
      <a href="index.html">Retornar</a>
      </body></html>
    `;
    respuesta.end(pagina);
    guardarUsuario(formulario);
  });
}
function guardarUsuario(formulario) {
  const idUsuario = formulario.get('ID_Usuario');
  const nombreUsuario = formulario.get('Nombre_Usuario');
  const emailUsuario = formulario.get('Email_Usuario');
  const telefonoUsuario = formulario.get('Telefono_Usuario');
  
  const query = 'CALL registrarUsuario(?, ?, ?, ?)';
  const values = [idUsuario, nombreUsuario, emailUsuario, telefonoUsuario];

  conexion.query(query, values, (error, results) => {
    if (error) {
      console.log('Error al guardar usuario:', error);
      return;
    }
    console.log('Usuario guardado correctamente:', results);
  });
}
function enviarContacto(pedido, respuesta) {
  let info = '';
  pedido.on('data', datosparciales => {
    info += datosparciales;
  });
  pedido.on('end', () => {
    const formulario = new URLSearchParams(info);
    console.log(formulario);
    respuesta.writeHead(200, { 'Content-Type': 'text/html' });
    const pagina = `
      <!doctype html><html><head></head><body>
      Nombre: ${formulario.get('nombre')}<br>
      Email: ${formulario.get('email')}<br>
      Teléfono: ${formulario.get('telefono')}<br>
      Comentario: ${formulario.get('comentario')}<br>
      <a href="index.html">Retornar</a>
      </body></html>
    `;
    respuesta.end(pagina);
    guardarContacto(formulario);
  });
}
function agendarCita(pedido, respuesta) {
  let info = '';
  pedido.on('data', datosparciales => {
    info += datosparciales;
  });
  pedido.on('end', () => {
    const formulario = new URLSearchParams(info);
    const idUsuario = formulario.get('ID_Usuario');
    const fechaCita = formulario.get('Fecha_Cita');
    
    verificarCita(idUsuario, fechaCita, (error, existeCita) => {
      if (error) {
        respuesta.writeHead(500, { 'Content-Type': 'text/html' });
        respuesta.write('<!doctype html><html><head></head><body>Error en la verificación de la cita.</body></html>');
        respuesta.end();
        return;
      }
      
      if (existeCita) {
        respuesta.writeHead(200, { 'Content-Type': 'text/html' });
        const pagina = `
          <!doctype html><html><head></head><body>
          Ya tienes una cita agendada para el ${fechaCita}.<br>
          <a href="index.html">Retornar</a>
          </body></html>
        `;
        respuesta.end(pagina);
      } else {
        
        guardarCita(formulario);
        respuesta.writeHead(200, { 'Content-Type': 'text/html' });
        const pagina = `
          <!doctype html><html><head></head><body>
          Cita agendada correctamente.<br>
          ID Usuario: ${formulario.get('ID_Usuario')}<br>
          Nombre: ${formulario.get('Nombre_Usuario')}<br>
          Fecha: ${formulario.get('Fecha_Cita')}<br>
          Hora: ${formulario.get('Hora_Cita')}<br>
          Servicio: ${formulario.get('Servicio_Cita')}<br>
          <a href="index.html">Retornar</a>
          </body></html>
        `;
        respuesta.end(pagina);
      }
    });
  });
}
function guardarCita(formulario) {
  const idUsuario = formulario.get('ID_Usuario');
  const nombreUsuario = formulario.get('Nombre_Usuario');
  const fechaCita = formulario.get('Fecha_Cita');
  const horaCita = formulario.get('Hora_Cita');
  const servicioCita = formulario.get('Servicio_Cita');
  
  const query = 'CALL agendarCita(?, ?, ?, ?, ?)';
  const values = [idUsuario, nombreUsuario, fechaCita, horaCita, servicioCita];

  conexion.query(query, values, (error, results) => {
    if (error) {
      console.log('Error al guardar cita:', error);
      return;
    }
    console.log('Cita guardada correctamente:', results);
  });
}
function verificarCita(idUsuario, fechaCita, callback) {
  const query = 'CALL ValidarCita(?, ?, @p_ExisteCita)';
  
  conexion.query(query, [idUsuario, fechaCita], (error) => {
    if (error) {
      console.log('Error al verificar cita:', error);
      callback(error, null);
      return;
    }

    
    conexion.query('SELECT @p_ExisteCita AS existe', (error, results) => {
      if (error) {
        console.log('Error al obtener resultado:', error);
        callback(error, null);
        return;
      }
      const existeCita = results[0].existe;
      callback(null, existeCita);
    });
  });
}
function obtenerCitas(respuesta) {
  const query = 'CALL obtenerCitas()'; 
  
  conexion.query(query, (error, results) => {
    if (error) {
      console.log('Error al obtener citas:', error);
      respuesta.writeHead(500, { 'Content-Type': 'text/plain' });
      respuesta.write('Error interno');
      respuesta.end();
      return;
    }

    let html = '<h2>Citas Registradas</h2><table border="1"><tr><th>ID Usuario</th><th>Nombre</th><th>Fecha</th><th>Hora</th><th>Servicio</th></tr>';
    results[0].forEach(cita => {
      html += `<tr>
        <td>${cita.ID_Usuario}</td>
        <td>${cita.Nombre_Usuario}</td>
        <td>${cita.Fecha_Cita}</td>
        <td>${cita.Hora_Cita}</td>
        <td>${cita.Servicio_Cita}</td>
      </tr>`;
    });
    html += '</table>';

    respuesta.writeHead(200, { 'Content-Type': 'text/html' });
    respuesta.write(html);
    respuesta.end();
  });
}
function guardarContacto(formulario) {
  const nombre = formulario.get('nombre');
  const email = formulario.get('email');
  const telefono = formulario.get('telefono');
  const comentario = formulario.get('comentario');
  const estado = 'Pendiente';

  const query = 'CALL enviarContacto(?, ?, ?, ?, ?)';
  const values = [nombre, email, telefono, comentario, estado];

  conexion.query(query, values, (error, results) => {
    if (error) {
      console.log('Error al guardar contacto:', error);
      return;
    }
    console.log('Contacto guardado correctamente:', results);
  });
}
function VerClientes(respuesta) {
  conexion.query('CALL ObtenerContactos()', (error, resultado) => {
    if (error) {
      console.log('Error obteniendo los contactos de la base de datos:', error);
      respuesta.writeHead(500, { 'Content-Type': 'text/html' });
      respuesta.end('<h1>Error en el servidor</h1>');
      return;
    }

    let filas = resultado[0];
    respuesta.writeHead(200, { 'Content-Type': 'text/html' });
    let datos = '';
    for (let f = 0; f < filas.length; f++) {
      datos += 'ID_Contacto:' + filas[f].ID_Contacto + '<br>';
      datos += 'Nombre:' + filas[f].Nombre + '<br>';
      datos += 'Email:' + filas[f].Email + '<br>';
      datos += 'Teléfono:' + filas[f].Telefono + '<br>';
      datos += 'Comentario:' + filas[f].Comentario + '<br>';
    }
    });
}
function verCitas(respuesta) {
  conexion.query('CALL obtenerCitas()', (error, resultado) => {
    if (error) {
      console.log('Error obteniendo las citas de la base de datos:', error);
      respuesta.writeHead(500, { 'Content-Type': 'text/html' });
      respuesta.end('<h1>Error en el servidor</h1>');
      return;
    }
    let filas = resultado[0];
    respuesta.writeHead(200, { 'Content-Type': 'text/html' });
    let datos = '';
    for (let f = 0; f < filas.length; f++) {
      datos += 'ID Usuario: ' + filas[f].ID_Usuario + '<br>';
      datos += 'Nombre: ' + filas[f].Nombre_Usuario + '<br>';
      datos += 'Fecha: ' + filas[f].Fecha_Cita + '<br>';
      datos += 'Hora: ' + filas[f].Hora_Cita + '<br>';
      datos += 'Servicio: ' + filas[f].Servicio_Cita + '<br><br>';
    }
    respuesta.end('<!doctype html><html><head><meta charset="UTF-8"><link rel="stylesheet" href="CSS/Estilo.css"></head><body><h2>Citas Registradas</h2>' + datos + '<a href="index.html">Retornar</a></body></html>');
  });
}
function actualizarUsuario(pedido, respuesta) {
  let info = '';
  pedido.on('data', datosparciales => {
    info += datosparciales;
  });
  pedido.on('end', () => {
    const formulario = new URLSearchParams(info);
    const idUsuario = formulario.get('ID_Usuario');
    const nombreUsuario = formulario.get('Nombre_Usuario');
    const emailUsuario = formulario.get('Email_Usuario');
    const telefonoUsuario = formulario.get('Telefono_Usuario');
    
    const query = 'CALL actualizarUsuario(?, ?, ?, ?)';
    const values = [idUsuario, nombreUsuario, emailUsuario, telefonoUsuario];
    
    conexion.query(query, values, (error, results) => {
      if (error) {
        console.log('Error al actualizar usuario:', error);
        respuesta.writeHead(500, { 'Content-Type': 'text/html' });
        respuesta.write('<!doctype html><html><head></head><body>Error al actualizar usuario.</body></html>');
        respuesta.end();
        return;
      }
      respuesta.writeHead(200, { 'Content-Type': 'text/html' });
      respuesta.write('<!doctype html><html><head></head><body>Usuario actualizado correctamente.<br><a href="index.html">Retornar</a></body></html>');
      respuesta.end();
    });
  });
}
function eliminarUsuario(pedido, respuesta) {
  let info = '';
  pedido.on('data', datosparciales => {
    info += datosparciales;
  });

  pedido.on('end', () => {
    const formulario = new URLSearchParams(info);
    const idUsuario = formulario.get('ID_Usuario');

    const query = 'CALL eliminarUsuario(?)';
    conexion.query(query, [idUsuario], (error, results) => {
      if (error) {
        console.log('Error al eliminar usuario:', error);
        respuesta.writeHead(500, { 'Content-Type': 'text/html' });
        respuesta.end('<h1>Error al eliminar usuario.</h1>');
        return;
      }
      console.log('Usuario eliminado correctamente:', results);
      respuesta.writeHead(200, { 'Content-Type': 'text/html' });
      respuesta.end('<h1>Usuario eliminado correctamente.</h1><a href="index.html">Retornar</a>');
    });
  });
}
function buscarComentario(pedido, respuesta) {
  const url = new URL('http://localhost:8888' + pedido.url);
  const nombre = url.searchParams.get('nombre');

  const query = 'SELECT * FROM Contactos WHERE Nombre = ? AND Estado = ?';
  const values = [nombre, 'Pendiente'];

  conexion.query(query, values, (error, results) => {
    if (error) {
      respuesta.writeHead(500, { 'Content-Type': 'text/plain' });
      respuesta.write('Error al buscar comentario');
      respuesta.end();
      console.log('Error al buscar comentario:', error);
      return;
    }

    let html = '<h2>Resultados de la Búsqueda</h2>';
    if (results.length > 0) {
      html += '<ul>';
      results.forEach(comentario => {
        html += `<li>
                  ID: ${comentario.ID_Contacto}, Nombre: ${comentario.Nombre}, Comentario: ${comentario.Comentario}
                  <form action="cambiar_estado" method="post" style="display:inline;">
                    <input type="hidden" name="id" value="${comentario.ID_Contacto}" />
                    <button type="submit">Marcar como Resuelto</button>
                  </form>
                 </li>`;
      });
      html += '</ul>';
    } else {
      html += '<p>No se encontraron comentarios pendientes con ese nombre.</p>';
    }

    respuesta.writeHead(200, { 'Content-Type': 'text/html' });
    respuesta.end(html);
  });
}
function cambiarEstadoComentario(pedido, respuesta) {
  let info = '';
  pedido.on('data', datosparciales => {
    info += datosparciales;
  });

  pedido.on('end', () => {
    const formulario = new URLSearchParams(info);
    const idContacto = formulario.get('id');

    const query = 'UPDATE Contactos SET Estado = ? WHERE ID_Contacto = ?';
    const values = ['Resuelto', idContacto];

    conexion.query(query, values, (error, results) => {
      if (error) {
        respuesta.writeHead(500, { 'Content-Type': 'text/plain' });
        respuesta.write('Error al actualizar el estado del comentario');
        respuesta.end();
        console.log('Error al actualizar el estado:', error);
        return;
      }

      respuesta.writeHead(200, { 'Content-Type': 'text/html' });
      respuesta.write('<p>El comentario ha sido marcado como Resuelto.</p>');
      respuesta.write('<a href="BuscarComentario.html">Regresar</a>');
      respuesta.end();
    });
  });
}
function consultarComentarios(pedido, respuesta) {
  const url = new URL('http://localhost:8888' + pedido.url);
  const estado = url.searchParams.get('estado');

  let query = 'SELECT * FROM Contactos';
  let values = [];

  if (estado && estado !== 'Todos') {
    query += ' WHERE Estado = ?';
    values = [estado];
  }

  conexion.query(query, values, (error, results) => {
    if (error) {
      respuesta.writeHead(500, { 'Content-Type': 'text/plain' });
      respuesta.write('Error al consultar comentarios');
      respuesta.end();
      console.log('Error al consultar comentarios:', error);
      return;
    }

    let html = '<h2>Resultados de la Consulta</h2>';
    html += '<table border="1">';
    html += '<thead><tr><th>ID</th><th>Nombre Completo</th><th>Correo</th><th>Comentario</th><th>Estado</th></tr></thead>';
    html += '<tbody>';

    results.forEach(comentario => {
      html += `<tr>
                <td>${comentario.ID_Contacto}</td>
                <td>${comentario.Nombre}</td>
                <td>${comentario.Email}</td>
                <td>${comentario.Comentario}</td>
                <td>${comentario.Estado}</td>
               </tr>`;
    });

    html += '</tbody></table>';

    respuesta.writeHead(200, { 'Content-Type': 'text/html' });
    respuesta.end(html);
  });
}
function mostrarComentarios(pedido, respuesta) {
  const query = 'SELECT * FROM contactos'; 

  conexion.query(query, (error, results) => {
    if (error) {
      respuesta.writeHead(500, { 'Content-Type': 'text/plain' });
      respuesta.write('Error al consultar comentarios');
      respuesta.end();
      console.log('Error al consultar comentarios:', error);
      return;
    }

    let html = '<h2>Lista de Comentarios</h2>';
    html += '<table border="1">';
    html += '<thead><tr><th>ID</th><th>Nombre Completo</th><th>Correo</th><th>Comentario</th><th>Estado</th></tr></thead>';
    html += '<tbody>';

    results.forEach(comentario => {
      html += `<tr>
                <td>${comentario.ID_Contacto}</td>
                <td>${comentario.Nombre}</td>
                <td>${comentario.Email}</td>
                <td>${comentario.Comentario}</td>
                <td>${comentario.Estado}</td>
               </tr>`;
    });

    html += '</tbody></table>';

    respuesta.writeHead(200, { 'Content-Type': 'text/html' });
    respuesta.end(html);
  });
}

//Servicios
function procesarPost(pedido, respuesta, callback) {
  let cuerpo = '';
  pedido.on('data', chunk => {
    cuerpo += chunk.toString();
  });
  pedido.on('end', () => {
    const datos = qs.parse(cuerpo);
    callback(datos, respuesta);
  });
}

function eliminarTarjeta(datos, respuesta) {
  const url = `http://localhost:3303/carta/${datos.NumeroTarjeta}`;
  axios.delete(url)
    .then(response => {
      respuesta.writeHead(200, { 'Content-Type': 'text/html' });
      respuesta.write('<p>Tarjeta eliminada correctamente</p>');
      respuesta.end();
    })
    .catch(error => {
      console.error('Error al eliminar tarjeta:', error);
      respuesta.writeHead(500, { 'Content-Type': 'text/plain' });
      respuesta.write('Error al eliminar tarjeta');
      respuesta.end();
    });
}
function obtenerTarjetas(respuesta) {
  const url = 'http://localhost:3303/carta';
  axios.get(url)
    .then(response => {
      respuesta.writeHead(200, { 'Content-Type': 'text/html' });
      respuesta.write('<h2>Lista de Tarjetas</h2><ul>');
      response.data.forEach(tarjeta => {
        respuesta.write(`<li>${tarjeta.NumeroTarjeta} - ${tarjeta.Monto} - ${tarjeta.IDPersona}</li>`);
      });
      respuesta.write('</ul>');
      respuesta.end();
    })
    .catch(error => {
      console.error('Error al obtener tarjetas:', error);
      respuesta.writeHead(500, { 'Content-Type': 'text/plain' });
      respuesta.write('Error al obtener tarjetas');
      respuesta.end();
    });
}
function agregarTarjeta(datos, respuesta) {
  const url = 'http://localhost:3303/carta';
  
  const { NumeroTarjeta, Monto, IDPersona } = datos; 

  axios.post(url, { NumeroTarjeta, Monto, IDPersona })
    .then(response => {
      respuesta.writeHead(200, { 'Content-Type': 'text/html' });
      respuesta.write('<p>Tarjeta añadida correctamente</p>');
      respuesta.end();
    })
    .catch(error => {
      console.error('Error al añadir tarjeta:', error);
      respuesta.writeHead(500, { 'Content-Type': 'text/plain' });
      respuesta.write('Error al añadir tarjeta');
      respuesta.end();
    });
}
function verificarDatos(datos, respuesta) {
  const { IDPersona } = datos;

  axios.get(`http://localhost:3300/carta/verificar/${IDPersona}`)
    .then(apiResponse => {
      const { Nombre, Apellidos, Direccion } = apiResponse.data;

      respuesta.writeHead(200, { 'Content-Type': 'text/html' });
      respuesta.write(`
        <form id="verificarDatosForm">
            <label for="idPersona">ID Persona:</label>
            <input type="number" id="idPersona" name="IDPersona" value="${IDPersona}" readonly>
            <br>
            <label for="nombre">Nombre:</label>
            <input type="text" id="nombre" name="Nombre" value="${Nombre}" readonly>
            <br>
            <label for="apellidos">Apellidos:</label>
            <input type="text" id="apellidos" name="Apellidos" value="${Apellidos}" readonly>
            <br>
            <label for="direccion">Dirección:</label>
            <input type="text" id="direccion" name="Direccion" value="${Direccion}" readonly>
            <br>
        </form>
      `);
      respuesta.end();
    })
    .catch(error => {
      console.error('Error al verificar datos personales:', error);

      respuesta.writeHead(404, { 'Content-Type': 'text/html' });
      respuesta.write('<p>ID Persona no encontrado</p>');
      respuesta.end();
    });
}
function verCitas_Servicio(respuesta) {
  const url = 'http://localhost:3304/carta'; 
  
  axios.get(url)
    .then(response => {
      respuesta.writeHead(200, { 'Content-Type': 'text/html' });
      respuesta.write('<h2>Lista de Citas</h2><ul>');
      response.data.forEach(cita => {
        respuesta.write(`
          <li>
            ID Cita: ${cita.ID_Cita} - 
            ID Usuario: ${cita.ID_Usuario} - 
            Fecha: ${cita.Fecha_Cita} - 
            Hora: ${cita.Hora_Cita} - 
            Servicio: ${cita.Servicio_Cita}
          </li>
        `);
      });
      respuesta.write('</ul>');
      respuesta.end();
    })
    .catch(error => {
      console.error('Error al obtener citas:', error);
      respuesta.writeHead(500, { 'Content-Type': 'text/plain' });
      respuesta.write('Error al obtener citas');
      respuesta.end();
    });
}
// Agregar un nuevo pago SINPE
function agregarSinpe(datos, respuesta) {
  const url = 'http://localhost:3302/carta'; 
  const { Telefono, Persona, NumeroCuenta, Monto } = datos;
  axios.post(url, { Telefono, Persona, NumeroCuenta, Monto })
      .then(response => {
          respuesta.writeHead(200, { 'Content-Type': 'text/html' });
          respuesta.write('<p>Pago añadido correctamente</p>');
          respuesta.end();
      })
      .catch(error => {
          console.error('Error al añadir pago SINPE:', error);
          respuesta.writeHead(500, { 'Content-Type': 'text/plain' });
          respuesta.write('Error al añadir pago SINPE');
          respuesta.end();
      });
}
function validarUsuario(datos, respuesta) {
  const url = 'http://localhost:3308/carta/verificar';

  axios.post(url, datos)
    .then(response => {
      respuesta.writeHead(200, { 'Content-Type': 'text/html' });
      respuesta.write('<p>' + response.data.message + '</p>');
      respuesta.end();
    })
    .catch(error => {
      console.error('Error al validar usuario:', error);
      respuesta.writeHead(401, { 'Content-Type': 'text/plain' });
      respuesta.write('Usuario o contraseña incorrectos');
      respuesta.end();
    });
}




console.log('Servidor web iniciado 8888');
