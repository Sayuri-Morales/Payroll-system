const express = require("express");
const app = express();
 
const dotenv = require("dotenv");
dotenv.config();
 
//conexión con la base de datos
const {connection} = require("../confbd.js");
 

const getLogin = (request, response) => {
    connection.query("SELECT * FROM login", (error, results) => {
        if (error) throw error;
        response.status(200).json(results);
    });
};


app.route("/Carta")
    .get(getLogin);


const postLogin = (request, response) => {
    const { Usuario, Contrasena } = request.body;
    connection.query("INSERT INTO login (Usuario, Contrasena) VALUES (?, ?)",
        [Usuario, Contrasena],
        (error, results) => {
            if (error) throw error;
            response.status(201).json({ "Item añadido correctamente": results.affectedRows });
        });
};

app.route("/Carta")
    .post(postLogin);


const delLogin = (request, response) => {
    const Usuario = request.params.Usuario;
    connection.query("DELETE FROM login WHERE Usuario = ?",
        [Usuario],
        (error, results) => {
            if (error) throw error;
            response.status(201).json({ "Item eliminado": results.affectedRows });
        });
};

app.route("/Carta/:Usuario")
    .delete(delLogin);

    const VerificarUsuario = (request, response) => {
        const { Usuario, Contrasena } = request.body;
    
        connection.query(
            "SELECT * FROM login WHERE Usuario = ? AND Contrasena = ?",
            [Usuario, Contrasena],
            (error, results) => {
                if (error) {
                    console.error('Error en la base de datos:', error);
                    response.status(500).json({ error: "Error en la base de datos" });
                    return;
                }
    
                if (results.length > 0) {
                    response.status(200).json({ message: "Autenticación exitosa" });
                } else {
                    response.status(401).json({ message: "Usuario o contraseña incorrectos" });
                }
            }
        );
    };
    
    // Ruta para verificar usuario y contraseña
    app.post("/carta/verificar", VerificarUsuario);

module.exports = app;